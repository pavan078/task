# Task 1

# Write a program that takes a list of numbers (for example, a = [5, 10, 15, 20, 25])
# and makes a new list of only the first and last elements of the given list. For practice, write this code inside a function.


def first_last_ele(lst):
    """
    Create a new list of only the first and last elements of the given list.

    Returns:
    list of two elements.
    """
    # Take only the first and last elements
    result = [lst[0], lst[-1]]
    return result

# Take numbers from user sample 1 2 3 
# For list of integers
lst = [int(x) for x in input().split()]
print(first_last_ele(lst))

