# Task 8

# Please write a program to compress and decompress the string "Music industry hails passage of the Music Modernization Act".


import zlib

s = "Music industry hails passage of the Music Modernization Act"

# using zlib.compress(s) method
print(zlib.compress(s.encode()))
# using zlib.decompress(s) method
print(zlib.decompress(zlib.compress(s.encode())))