# Task 3

# Take two lists, say for example these two:
#
# a = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89]
# b = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]
#
# and write a program that returns a list that contains only the elements that are common between the lists (without duplicates).
# Make sure your program works on two lists of different sizes.
#
# Extras:
#   1. Randomly generate two lists to test this
#   2. Write this in one line of Python

import numpy as np

# Randomly generate two lists lst1 and lst2
lst1 = list(np.random.randint(low=3, high=8, size=10))
lst2 = list(np.random.randint(low=3, high=8, size=10))
print("list1 = {},\nlist2 = {}".format(lst1, lst2))
# list that contains only the elements that are common between the lists
print("Common elements are", list(set(lst1) & set(lst2)))
