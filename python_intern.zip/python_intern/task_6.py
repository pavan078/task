# Task 6

# Write the Task 5 titles to the text file.

# Extras:
# Ask the user to specify the name of the output file that will be saved.

import logging
from urllib.parse import urljoin
import requests
from bs4 import BeautifulSoup


class Crawler:
    def __init__(self, urls=[]):
        global heading_lst
        self.urls_to_visit = urls
        heading_lst = []  # a list to store news titles

    def get_linked_urls(self, url, html):
        soup = BeautifulSoup(html, "html.parser")
        links = soup.find_all("a", class_="titlelink")
        for link in links:
            try:
                # extracting the news titles
                head = str(link).split('">')
                news_titles = head[1].split("</a>")[0]
                heading_lst.append(news_titles)
            except:
                continue

    def crawl(self, url):
        html = requests.get(url).text
        self.get_linked_urls(url, html)

    def run(self):
        url = self.urls_to_visit.pop(0)
        logging.info(f"Crawling: {url}")
        try:
            self.crawl(url)
        except Exception:
            logging.exception(f"Failed to crawl: {url}")


if __name__ == "__main__":
    file_name = input("Input the Filename: ")
    Crawler(urls=["https://news.ycombinator.com/"]).run()
    with open(file_name, "w") as filehandle:
        for listitem in heading_lst:
            filehandle.write("%s\n" % listitem)
