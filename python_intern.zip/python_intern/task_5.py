# Task 5

# Use the BeautifulSoup and requests Python packages to print out a list of all the news titles on the https://news.ycombinator.com/.


import logging
from urllib.parse import urljoin
import requests
from bs4 import BeautifulSoup


class Crawler:
    def __init__(self, urls=[]):
        global heading_lst
        self.urls_to_visit = urls
        heading_lst = []  # a list to store news titles

    def get_linked_urls(self, url, html):
        soup = BeautifulSoup(html, "html.parser")
        links = soup.find_all("a", class_="titlelink")
        for link in links:
            try:
                # extracting the news titles
                head = str(link).split('">')
                final_res = head[1].split("</a>")[0]
                heading_lst.append(final_res)
                print(final_res)
            except:
                continue

    def crawl(self, url):
        html = requests.get(url).text
        self.get_linked_urls(url, html)

    def run(self):
        url = self.urls_to_visit.pop(0)
        logging.info(f"Crawling: {url}")
        try:
            self.crawl(url)
        except Exception:
            logging.exception(f"Failed to crawl: {url}")


if __name__ == "__main__":
    Crawler(urls=["https://news.ycombinator.com/"]).run()
