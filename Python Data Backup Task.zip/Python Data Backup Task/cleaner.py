""" Python Backup Cleaner

Buckets 1 and 2 contain backup of code and database respectively.  
Each file name contains the date it was backed up on.

Your task is to **delete** the files from these buckets that do not fit the below criteria.

Following files are to be kept and rest are to be deleted:
1. backups of last 5 days
2. backups of last 4 Saturdays
3. backups of last day of each month
"""

import datetime
import calendar
import glob
import os


class Cleaner:
    def __init__(self):
        self.latest_date = "2020-09-17"
        self.initiator()

    def initiator(self):
        """To get the list of last four saturday and last five days"""
        self.last_five_days = list()
        self.last_four_saturday = list()
        datetime_object = datetime.datetime.strptime(self.latest_date, "%Y-%m-%d")

        # appending last five days to list
        for i in range(5):
            previous_date = datetime_object - datetime.timedelta(days=i)
            self.last_five_days.append(previous_date)

        # appending last four saturday to list
        idx = (datetime_object.weekday() + 1) % 7
        saturday = datetime_object - datetime.timedelta(7 + idx - 6)
        self.last_four_saturday.append(saturday)
        for i in range(3):
            last_saturday = self.last_four_saturday[-1] - datetime.timedelta(days=7)
            self.last_four_saturday.append(last_saturday)

    def __is_last_day(self, date):
        """
        To find the given day is last day of the month.

        Arguments:
        date which is extracted from file name

        Returns:
        True if passed date is matched with last day of the month.
        """
        last_day_of_month = calendar.monthrange(date.year, date.month)[1]
        if date.day == last_day_of_month:
            return True

    def __is_date_last_five_days(self, date):
        """
        To find the given day satifies the condition of last five days

        Arguments:
        date which is extracted from file name

        Returns:
        True if passed date in present in list of last five days.
        """
        if date in self.last_five_days:
            return True

    def __is_date_last_four_sat(self, date):
        """
        To find the given day satifies the condition of last four sat.

        Arguments:
        date which is extracted from file name

        Returns:
        True if passed date in present in list of last four saturdays.
        """
        if date in self.last_four_saturday:
            return True

    def remove_files(self):
        """To remove the files which doesnt satifies the condition"""
        path = "./"
        text_files = glob.glob(path + "/**/*.txt", recursive=True)
        for file in text_files:
            # Extracting the date from filename
            ext_date = file.split("_")[-1].split(".")[0]
            date = datetime.datetime.strptime(ext_date, "%Y-%m-%d")
            if (
                self.__is_last_day(date) == True
                or self.__is_date_last_five_days(date) == True
                or self.__is_date_last_four_sat(date) == True
            ):
                continue
            else:
                os.remove(file)


if __name__ == "__main__":
    c1 = Cleaner()
    c1.remove_files()
